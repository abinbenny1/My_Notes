package com.canadore.mynotes

class NotesActivity {

}
