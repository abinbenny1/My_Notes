package com.canadore.mynotes

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*

class NotesListActivity : AppCompatActivity() {

    private lateinit var notesRecyclerView: RecyclerView
    private lateinit var notesAdapter: NotesAdapter
    private lateinit var notesList: MutableList<Note>
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notes_list)

        // Initialize RecyclerView
        notesRecyclerView = findViewById(R.id.notesRecyclerView)
        notesRecyclerView.layoutManager = LinearLayoutManager(this)

        // Initialize notes list and adapter
        notesList = mutableListOf()
        notesAdapter = NotesAdapter(notesList)
        notesRecyclerView.adapter = notesAdapter

        // Initialize Firebase database reference
        database = FirebaseDatabase.getInstance().getReference("Notes")

        // Fetch notes from Firebase
        fetchNotes()
    }

    private fun fetchNotes() {
        // Add Firebase listener to retrieve data
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                notesList.clear() // Clear the list to avoid duplicates
                for (noteSnapshot in snapshot.children) {
                    // Parse each note object
                    val note = noteSnapshot.getValue(Note::class.java)
                    if (note != null) {
                        notesList.add(note) // Add each note to the list
                    }
                }
                // Notify adapter that data has changed
                notesAdapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@NotesListActivity, "Failed to load notes", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
