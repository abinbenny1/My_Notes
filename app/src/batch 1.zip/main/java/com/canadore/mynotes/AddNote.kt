package com.canadore.mynotes

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AddNote : AppCompatActivity() {

    private lateinit var noteHeading: EditText
    private lateinit var noteDescription: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_note)

        noteHeading = findViewById(R.id.noteHeading)
        noteDescription = findViewById(R.id.noteDescription)
        val saveButton: Button = findViewById(R.id.saveButton)

        saveButton.setOnClickListener {
            val heading = noteHeading.text.toString().trim()
            val description = noteDescription.text.toString().trim()

            if (heading.isNotEmpty() && description.isNotEmpty()) {
                Toast.makeText(this, "Note Saved: $heading", Toast.LENGTH_SHORT).show()
                // Here you can implement saving functionality (e.g., save to database)
            } else {
                Toast.makeText(this, "Please enter both heading and description", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
